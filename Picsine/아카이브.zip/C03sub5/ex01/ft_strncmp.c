/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sehyan <sehyan@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/01 09:40:41 by sehyan            #+#    #+#             */
/*   Updated: 2020/12/08 09:21:45 by sehyan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;
	unsigned char	uc1;
	unsigned char	uc2;

	i = 0;
	while (s1[i] == s2[i] && s1[i] && s2[i] && i < n)
		i++;
	if (i == n)
		return (0);
	if (s1[i] == s2[i])
		return (0);
	uc1 = s1[i];
	uc2 = s2[i];
	if (uc1 > uc2)
		return (1);
	if (uc1 < uc2)
		return (-1);
	return (0);
}
