/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sehyan <sehyan@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/01 11:47:40 by sehyan            #+#    #+#             */
/*   Updated: 2020/12/03 10:07:19 by sehyan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int i;
	unsigned int sl;
	unsigned int dl;

	sl = 0;
	dl = 0;
	while (src[sl] != '\0')
		sl++;
	if (size == 0)
		return (sl);
	while (dest[dl] != '\0')
		dl++;
	if (size <= dl)
		return (sl + size);
	i = 0;
	while (i + dl + 1 < size && src[i] != '\0')
	{
		dest[dl + i] = src[i];
		i++;
	}
	dest[dl + i] = '\0';
	return (dl + sl);
}
